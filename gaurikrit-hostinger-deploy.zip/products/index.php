<?php
/**
 * Gaurikrit Bio Products — Products Overview (V18 client-asset integration).
 *
 * THE GAURIKRIT PRODUCT ECOSYSTEM — one natural resource, multiple useful
 * applications (V18 §41 order):
 *   1. Hero — "One natural resource. Multiple useful applications." The
 *      official pair photo stays (the documented products).
 *   2. Eco-Paints family section (#eco-paints) — the DEEPEST section
 *      because verified content exists: intro + pair photo + the four
 *      contextual links (Distemper / Emulsion / Calculator / Why).
 *   3. Distemper chapter (cool format wash — catalogue plate).
 *   4. Emulsion chapter (warm format wash — catalogue plate, reversed).
 *   5. Spec matrix + coverage note (factual data only).
 *   6. Colour-collection callout — two client-supplied collections
 *      → /colours/ (V18 §20; the 8-benefit grid now lives ONLY in
 *      Eco-Paints educational contexts, not here).
 *   7. Cow-Dung Logs (#cow-dung-logs) — client artwork (legacy #gocast-logs)
 *      photography, editorial 45/55 composition (V18 §16–17).
 *   8. Bio-Briquettes (#bio-briquettes) — client artwork (legacy #bio-coal-logs).
 *   9. Utility Products (#utility-products) — same (§34).
 *  10. Application map — "Where the Ecosystem Works." (§35).
 *  11. Final CTA (FAQ retired — §41: no generic paint FAQ here).
 *
 * No fake category detail pages — the three undocumented families are
 * presented HERE properly, with enquiry links, never Lorem ipsum.
 */
declare(strict_types=1);

$pageTitle       = 'Products — Eco-Paints, Biomass & Sustainable Material Solutions | Gaurikrit';
$pageDescription = 'The Gaurikrit product ecosystem: Eco-Paints (Prakritik Distemper and Emulsion, fully documented) plus Cow-Dung Logs, Bio-Briquettes and Utility Product development directions — one natural resource, multiple applications.';
$pageCanonical   = '/products/';
$pageClass       = 'products';

require_once __DIR__ . '/../../includes/bootstrap.php';
require ROOT_PATH . '/includes/header.php';

global $COMPANY, $PRODUCTS, $COVERAGE_DISCLAIMER, $FAMILIES, $APPLICATION_GROUPS, $SHADE_SIGNATURE;

$distemper   = get_product('prakritik-distemper');
$emulsion    = get_product('prakritik-emulsion');
// V11: the products hero carries the client's official two-bucket comparison
// image (Distemper left, Emulsion right) — the documented Eco-Paints family.
?>
<style>
  /* ===== Editorial image reset (V4 — NO mix-blend-mode, NO blur filters) ===== */
  .editorial-image {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  /* ===== 1. ECOSYSTEM HERO (45 / 55) — the official pair photo on a quiet
     catalogue plate: hairline border, paper ground, natural 1420/618
     aspect. No min-height dead zones, no accent stripe, no shadow. ===== */
  .products-hero {
    padding-top: calc(var(--header-h) + 2rem);
    padding-bottom: 1.5rem;
  }
  .products-hero__grid {
    display: grid; gap: 2.5rem; align-items: center;
    grid-template-columns: minmax(0, 1fr);
  }
  @media (min-width: 1024px) {
    .products-hero__grid { grid-template-columns: minmax(0, 45fr) minmax(0, 55fr); gap: clamp(2rem, 4vw, 4rem); }
  }
  .products-hero__lockup { max-width: 42rem; }
  /* V19: the pair master carries its own sweep — full-bleed, no box. */
  .products-hero__visual {
    position: relative; width: 100%;
    overflow: hidden;
  }
  .products-hero__visual .hero-group-photo {
    display: block;
    width: 100%; height: auto;
    border-radius: 0.1875rem;
  }

  /* V19 §36: representative category photos for Bio-Coal + Utility —
     same 4:3 frame treatment, honest caption. Retires the type plate. */
  .family-section__photo {
    border: 1px solid var(--border); border-radius: var(--r-panel);
    overflow: hidden; background: var(--paper); margin: 0;
  }
  .family-section__photo img {
    display: block; width: 100%; height: auto;
    transition: transform var(--dur) var(--ease);
  }
  .family-section__photo:hover img { transform: scale(1.015); }
  .family-section__photo figcaption {
    padding: 0.625rem 1rem; font-size: 0.75rem; color: var(--fg-muted);
    border-top: 1px solid var(--border); letter-spacing: 0.02em;
  }
  .family-section__poster {
    margin-top: 2rem; max-width: 28rem; margin-left: auto; margin-right: auto;
  }
  @media (min-width: 768px) {
    .family-section__poster { margin-left: 0; margin-right: 0; }
  }
  .family-section__poster-figure {
    margin: 0; background: var(--paper-warm); border: 1px solid var(--border);
    border-radius: var(--r-card); overflow: hidden;
  }
  .family-section__poster-figure picture {
    display: block; aspect-ratio: 1 / 1; width: 100%;
  }
  .family-section__poster-figure img {
    width: 100%; height: 100%; object-fit: contain; display: block;
  }
  .family-section__poster-figure figcaption {
    padding: 0.625rem 1rem; font-size: 0.75rem; color: var(--fg-muted);
    border-top: 1px solid var(--border); letter-spacing: 0.02em;
  }

  /* ===== 2. ECO-PAINTS FAMILY SECTION — documented family: intro copy,
     the pair photo as the family's real product photography, and the
     four contextual links (§31). ===== */
  .eco-family { padding-block: clamp(3rem, 6vw, 5rem); }
  .eco-family__grid {
    display: grid; gap: 2.5rem; align-items: center;
    grid-template-columns: minmax(0, 1fr);
  }
  @media (min-width: 1024px) {
    .eco-family__grid { grid-template-columns: minmax(0, 5fr) minmax(0, 7fr); gap: clamp(2rem, 4vw, 4rem); }
  }
  .eco-family__plate {
    background: none;
    border: 0;
    border-radius: 0;
    padding: 0;
  }
  .eco-family__plate img {
    display: block; width: 100%; height: auto;
  }
  .eco-family__head { display: flex; align-items: baseline; gap: 0.875rem; }
  .eco-family__num {
    font-family: var(--font-display); font-size: clamp(2rem, 3vw, 2.75rem);
    font-weight: 700; color: var(--haldi-deep); line-height: 1;
    font-variant-numeric: tabular-nums;
  }
  .eco-family__name {
    font-family: var(--font-display); font-size: clamp(1.875rem, 3.5vw, 3rem);
    font-weight: 700; letter-spacing: -0.02em; line-height: 1.05;
  }
  .eco-family__line {
    font-family: var(--font-display); font-style: italic;
    font-size: 1.125rem; color: var(--primary); margin-top: 0.75rem;
  }
  .eco-family__sub { margin-top: 1rem; max-width: 40rem; line-height: 1.65; }
  .eco-family__links {
    margin-top: 1.75rem; display: flex; flex-wrap: wrap; gap: 0.75rem;
  }

  /* ===== 7/8/9. UNDOCUMENTED FAMILY SECTIONS (§32–34) — editorial split:
     copy left, quiet material plate right. Honest, never fabricated. ===== */
  .family-section { padding-block: clamp(3rem, 6vw, 5rem); }
  .family-section__grid {
    display: grid; gap: 2.5rem; align-items: center;
    grid-template-columns: minmax(0, 1fr);
  }
  @media (min-width: 1024px) {
    .family-section__grid { grid-template-columns: minmax(0, 7fr) minmax(0, 5fr); gap: clamp(2.5rem, 5vw, 4.5rem); }
    .family-section--reverse .family-section__grid { grid-template-columns: minmax(0, 5fr) minmax(0, 7fr); }
    .family-section--reverse .family-section__copy { order: 2; }
  }
  .family-section__num {
    font-family: var(--font-display); font-size: clamp(2rem, 3vw, 2.75rem);
    font-weight: 700; color: var(--haldi-deep); line-height: 1;
    font-variant-numeric: tabular-nums;
  }
  .family-section__name {
    font-family: var(--font-display); font-size: clamp(1.75rem, 3.5vw, 2.75rem);
    font-weight: 700; letter-spacing: -0.02em; line-height: 1.05; margin-top: 0.5rem;
  }
  .family-section__line {
    font-family: var(--font-display); font-style: italic;
    font-size: 1.125rem; color: var(--primary); margin-top: 0.625rem;
  }
  .family-section__desc { margin-top: 1rem; max-width: 40rem; line-height: 1.7; }
  .family-section__themes {
    list-style: none; margin-top: 1.25rem;
    display: flex; flex-direction: column; gap: 0.5rem;
    border-top: 1px solid var(--border); padding-top: 1.125rem;
  }
  .family-section__themes li {
    font-size: 0.875rem; color: var(--fg-muted);
    padding-left: 1.125rem; position: relative; line-height: 1.5;
  }
  .family-section__themes li::before {
    content: ""; position: absolute; left: 0; top: 0.5em;
    width: 0.4375rem; height: 1px; background: var(--primary);
  }
  .family-section__note {
    margin-top: 1.5rem; font-size: 0.8125rem; color: var(--fg-muted);
    line-height: 1.55; border-left: 2px solid var(--haldi);
    padding-left: 1rem; max-width: 40rem;
  }
  .family-section__plate {
    position: relative; aspect-ratio: 4 / 5; max-height: 28rem;
    border: 1px solid var(--border); border-radius: var(--r-panel);
    overflow: hidden; background: var(--paper);
  }
  .family-section__plate-texture {
    position: absolute; inset: 0; opacity: 0.15;
  }
  .family-section__plate-texture img { width: 100%; height: 100%; object-fit: cover; }
  .family-section__plate-word {
    position: absolute; inset: 0; display: flex; align-items: center;
    justify-content: center; text-align: center; padding: 2rem;
    font-family: var(--font-display); font-weight: 700;
    font-size: clamp(1.5rem, 2.5vw, 2.25rem); color: var(--primary);
    line-height: 1.15;
  }
  .family-section__plate-tag {
    position: absolute; left: 1rem; bottom: 0.875rem;
    font-size: 0.5625rem; font-weight: 700; letter-spacing: 0.16em;
    text-transform: uppercase; color: var(--fg-muted);
  }
  .family-section__cta { margin-top: 1.75rem; }

  /* ===== SPEC MATRIX (V5: header row + zebra striping + taller rows) ===== */
  .spec-matrix-section { padding-block: clamp(3rem, 6vw, 5rem); }
  .spec-matrix-section__head { max-width: 48rem; margin-bottom: 2.5rem; }
  .spec-matrix {
    border: 1px solid var(--border);
    border-radius: var(--r-panel);
    overflow: hidden;
    background: var(--paper);
  }
  .spec-matrix__row {
    grid-template-columns: minmax(0, 1fr); gap: 0.75rem;
    padding: 1.75rem 1.25rem;
    border-bottom: 1px solid var(--border);
  }
  @media (min-width: 768px) {
    .spec-matrix__row {
      grid-template-columns: 12rem 1fr 1fr; gap: 1.5rem; padding: 1.75rem 1.5rem;
    }
  }
  .spec-matrix__row:nth-child(even) {
    background: color-mix(in srgb, var(--haldi) 3%, transparent);
  }
  .spec-matrix__row:first-child {
    border-bottom: 2px solid var(--forest);
    background: color-mix(in srgb, var(--limewash) 80%, var(--paper));
  }
  .spec-matrix__row:last-child { border-bottom: 0; }
  .spec-matrix__col-head {
    font-size: 0.8125rem; font-weight: 700; letter-spacing: 0.14em;
    text-transform: uppercase; color: var(--forest);
  }
  .spec-matrix__col-head--distemper { color: var(--indigo); }
  .spec-matrix__col-head--emulsion { color: var(--leaf); }
  .spec-matrix__label {
    font-weight: 700 !important;
    font-size: 0.875rem !important;
    color: var(--fg) !important;
    letter-spacing: 0.02em;
  }
  .spec-matrix__value {
    font-weight: 600 !important;
    color: var(--fg) !important;
  }
  .spec-matrix-mobile { display: none; }
  @media (max-width: 639px) {
    .spec-matrix { display: none; }
    .spec-matrix-mobile { display: grid; gap: 1.5rem; }
  }
  .spec-matrix-mobile__block {
    border: 1px solid var(--border);
    border-top: 3px solid var(--forest);
    border-radius: var(--r-panel);
    background: var(--paper);
    overflow: hidden;
  }
  .spec-matrix-mobile__block--emulsion { border-top-color: var(--leaf); }
  .spec-matrix-mobile__name {
    padding: 1rem 1.25rem;
    font-size: 0.8125rem; font-weight: 700; letter-spacing: 0.14em;
    text-transform: uppercase; color: var(--forest);
    background: color-mix(in srgb, var(--limewash) 80%, var(--paper));
    border-bottom: 1px solid var(--border);
  }
  .spec-matrix-mobile__block--emulsion .spec-matrix-mobile__name { color: var(--leaf); }
  .spec-matrix-mobile__row {
    display: flex; justify-content: space-between; align-items: baseline; gap: 1rem;
    padding: 0.75rem 1.25rem;
    border-bottom: 1px solid var(--border);
  }
  .spec-matrix-mobile__row:last-child { border-bottom: 0; }
  .spec-matrix-mobile__row .k {
    font-size: 0.75rem; font-weight: 700; letter-spacing: 0.08em;
    text-transform: uppercase; color: var(--fg-muted);
  }
  .spec-matrix-mobile__row .v { font-weight: 600; color: var(--fg); text-align: right; }

  /* ===== BENEFITS — the shared typographic grid (app.css §18) ===== */
  .benefits-strip { padding-block: clamp(3rem, 6vw, 5rem); }
  .benefits-strip__head { max-width: 48rem; margin-bottom: 2rem; }

  /* ===== APPLICATION MAP (§35) ===== */
  .appmap-section { padding-block: clamp(3rem, 6vw, 5rem); }
  .appmap-section__head { max-width: 48rem; margin-bottom: 2.5rem; }

  /* ===== COLOUR COLLECTIONS CALLOUT (§20 / §48.5) ===== */
  .colour-cta-section { padding-block: clamp(2.75rem, 5vw, 4rem); }

  /* ===== GOCAST EDITORIAL FEATURE (§16 / §48.6) — copy numbering echo ===== */
  .gocast-feature__copy .family-section__num { display: block; margin-bottom: 0.75rem; }
  .gocast-feature__copy .family-section__name { margin-bottom: 0.5rem; }
  .gocast-feature__copy .family-section__line { margin-bottom: 1.125rem; }
  .gocast-feature__copy .family-section__themes { margin-top: 1.25rem; }
  .gocast-feature__copy .family-section__cta { margin-top: 1.75rem; }
</style>

<!-- ============================================================
     1. HERO — THE GAURIKRIT PRODUCT ECOSYSTEM (§30)
     ============================================================ -->
<section class="products-hero bg-limewash" aria-labelledby="products-hero-title">
  <div class="container">
    <nav class="breadcrumb" aria-label="Breadcrumb">
      <a href="/">Home</a><span>›</span>
      <span>Products</span>
    </nav>
    <div class="products-hero__grid">
      <div class="products-hero__lockup" data-reveal>
        <span class="eyebrow"><span class="products-hero__eyebrow-dot" aria-hidden="true"></span>The Gaurikrit Product Ecosystem</span>
        <hr class="products-hero__rule">
        <h1 class="products-hero__title" id="products-hero-title">One Natural Resource, Multiple Useful Applications</h1>
        <p class="products-hero__sub">
          Cow dung is the shared material beginning. Gaurikrit develops it in
          four directions — Eco-Paints is the documented family; Cow-Dung Logs
          is a development direction; Bio-Briquettes and Eco Utility Products
          are Futureline product directions, not yet in production.
        </p>
      </div>
      <div class="products-hero__visual" data-reveal>
        <picture>
          <source type="image/avif" srcset="<?= eco_srcset('eco-paints-pair', [640, 960, 1280, 1600, 1920]) ?>"
                  sizes="(min-width: 1200px) 52vw, (min-width: 900px) 48vw, calc(100vw - 2.5rem)">
          <source type="image/webp" srcset="<?= eco_srcset_webp('eco-paints-pair', [640, 960, 1280, 1600, 1920]) ?>"
                  sizes="(min-width: 1200px) 52vw, (min-width: 900px) 48vw, calc(100vw - 2.5rem)">
          <img class="hero-group-photo"
               src="<?= asset_url('/assets/images/ecosystem/eco-paints-pair-1280.jpg') ?>"
               alt="Prakritik Distemper and Emulsion paint packs — the documented Eco-Paints family"
               width="1280" height="800"
               loading="eager" fetchpriority="high" decoding="async">
        </picture>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     1b. CLIENT ECOSYSTEM BANNER — GBP Products Banner
     Client-supplied wide banner showing the product range. The banner
     uses present-tense marketing language; Bio-Briquettes and Eco Utility
     Products shown in it are Futureline products, not yet in production.
     ============================================================ -->
<section class="section section--paper" aria-labelledby="ecosystem-banner-title" style="padding-block: clamp(2rem, 4vw, 3rem);">
  <div class="container">
    <div class="section-heading section-heading--left" data-reveal style="max-width: 48rem; margin-bottom: 1.5rem;">
      <span class="section-heading__eyebrow">Product Directions</span>
      <h2 class="section-heading__title" id="ecosystem-banner-title" style="font-size: clamp(1.5rem, 3vw, 2rem);">The Gaurikrit product range</h2>
      <p class="section-heading__desc">
        All four Gaurikrit product directions in one view — from the
        documented Eco-Paints family to the Futureline directions still
        in development.
      </p>
    </div>
    <figure class="journey-infographic" data-reveal>
      <picture>
        <source type="image/avif" srcset="<?= eco_srcset('products-banner', [640, 960, 1280, 1536]) ?>"
                sizes="(min-width: 1024px) 80vw, calc(100vw - 2.5rem)">
        <source type="image/webp" srcset="<?= eco_srcset_webp('products-banner', [640, 960, 1280, 1536]) ?>"
                sizes="(min-width: 1024px) 80vw, calc(100vw - 2.5rem)">
        <img src="<?= asset_url('/assets/images/ecosystem/products-banner-1280.jpg') ?>"
             alt="Official Gaurikrit product range banner — Eco-Paints, Cow-Dung Logs, Bio-Briquettes (Futureline) and Eco Utility Products (Futureline). The Futureline products are not yet in production."
             width="1536" height="1024" loading="lazy" decoding="async">
      </picture>
      <figcaption>The official Gaurikrit product range &mdash; Bio-Briquettes and Eco Utility Products are Futureline products, not yet in production.</figcaption>
    </figure>
  </div>
</section>

<!-- ============================================================
     2. ECO-PAINTS — the documented family (§31)
     Deepest section: real product photography + contextual links.
     ============================================================ -->
<section class="section section--paper eco-family" id="eco-paints" aria-labelledby="eco-family-title">
  <div class="container">
    <div class="eco-family__grid" data-reveal>
      <div class="eco-family__copy">
        <div class="eco-family__head">
          <span class="eco-family__num" aria-hidden="true">01</span>
          <h2 class="eco-family__name" id="eco-family-title">Eco-Paints</h2>
        </div>
        <p class="eco-family__line">Healthy walls inspired by nature.</p>
        <p class="eco-family__sub">
          Cow dung-based wall coatings in Distemper and Emulsion formats — the
          most developed family in the Gaurikrit ecosystem, documented with
          full product specifications.
        </p>
        <div class="eco-family__links">
          <a class="btn btn--primary" href="<?= e($distemper['route']) ?>">View Distemper</a>
          <a class="btn btn--secondary" href="<?= e($emulsion['route']) ?>">View Emulsion</a>
          <a class="btn btn--outline" href="/paint-calculator/">Painting Calculator</a>
          <a class="btn btn--outline" href="/why-prakritik/">Why Prakritik?</a>
        </div>
      </div>
      <div class="eco-family__plate" data-reveal>
        <picture>
          <source type="image/avif" srcset="<?= eco_srcset('eco-paints-pair', [640, 960, 1280, 1920]) ?>"
                  sizes="(min-width: 1024px) 45vw, calc(100vw - 2.5rem)">
          <source type="image/webp" srcset="<?= eco_srcset_webp('eco-paints-pair', [640, 960, 1280, 1920]) ?>"
                  sizes="(min-width: 1024px) 45vw, calc(100vw - 2.5rem)">
          <img src="<?= asset_url('/assets/images/ecosystem/eco-paints-pair-1280.jpg') ?>"
               alt="Prakritik Distemper and Emulsion paint packs — real Eco-Paints product photography"
               width="1280" height="800"
               loading="lazy" decoding="async">
        </picture>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     3. DISTEMPER PRODUCT CHAPTER — catalogue plate
     (complete pack photo + interior-finish strip; structure in app.css §14)
     ============================================================ -->
<section class="product-chapter product-chapter--distemper" aria-labelledby="distemper-chapter-title">
  <div class="container">
    <div class="product-chapter__inner" data-reveal>
      <figure class="product-chapter__visual">
        <div class="product-chapter__stage">
          <picture>
            <source type="image/webp" srcset="<?= asset_url($distemper['officialImageWebp']) ?>">
            <img class="chapter-product chapter-product--distemper"
                 src="<?= asset_url($distemper['officialImage']) ?>"
                 alt="<?= e($distemper['name']) ?> paint pack"
                 width="<?= $distemper['officialImageW'] ?>" height="<?= $distemper['officialImageH'] ?>"
                 loading="lazy" decoding="async">
          </picture>
        </div>
        <div class="product-chapter__strip" aria-hidden="true">
          <picture>
            <source type="image/webp" srcset="<?= asset_url('/assets/editorial/interior-finish-study.webp') ?>">
            <img class="chapter-strip"
                 src="<?= asset_url('/assets/editorial/interior-finish-study.jpg') ?>"
                 alt=""
                 width="1344" height="768"
                 loading="lazy" decoding="async">
          </picture>
        </div>
      </figure>
      <div class="product-chapter__copy">
        <span class="product-chapter__eyebrow">Eco-Paints — Distemper</span>
        <h2 class="product-chapter__name" id="distemper-chapter-title">
          <?= e($distemper['name']) ?>
        </h2>
        <p class="product-chapter__desc">
          <?= e($distemper['descriptor']) ?>. A paint listed for
          interior and exterior walls. Supplied in <?= e($distemper['packagingShort']) ?> packs.
        </p>
        <dl class="product-chapter__specs">
          <div class="duo-panel__row"><dt>Finish</dt><dd><?= e($distemper['finish']) ?></dd></div>
          <div class="duo-panel__row"><dt>Drying time</dt><dd><?= e($distemper['dryingTime']) ?></dd></div>
          <div class="duo-panel__row"><dt>Coverage</dt><dd><?= e($distemper['coverage']) ?></dd></div>
          <div class="duo-panel__row"><dt>V.O.C.</dt><dd><?= e($distemper['voc']) ?></dd></div>
        </dl>
        <div class="product-chapter__cta">
          <a class="btn btn--secondary" href="<?= e($distemper['route']) ?>">View Distemper</a>
          <a class="btn btn--outline" href="/contact/?interest=prakritik-distemper">Enquire About Distemper</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     4. EMULSION PRODUCT CHAPTER (reversed) — catalogue plate
     ============================================================ -->
<section class="product-chapter product-chapter--emulsion" aria-labelledby="emulsion-chapter-title">
  <div class="container">
    <div class="product-chapter__inner" data-reveal>
      <figure class="product-chapter__visual">
        <div class="product-chapter__stage">
          <picture>
            <source type="image/webp" srcset="<?= asset_url($emulsion['officialImageWebp']) ?>">
            <img class="chapter-product chapter-product--emulsion"
                 src="<?= asset_url($emulsion['officialImage']) ?>"
                 alt="<?= e($emulsion['name']) ?> paint pack"
                 width="<?= $emulsion['officialImageW'] ?>" height="<?= $emulsion['officialImageH'] ?>"
                 loading="lazy" decoding="async">
          </picture>
        </div>
        <div class="product-chapter__strip" aria-hidden="true">
          <picture>
            <source type="image/webp" srcset="<?= asset_url('/assets/editorial/exterior-finish-study.webp') ?>">
            <img class="chapter-strip"
                 src="<?= asset_url('/assets/editorial/exterior-finish-study.jpg') ?>"
                 alt=""
                 width="1344" height="768"
                 loading="lazy" decoding="async">
          </picture>
        </div>
      </figure>
      <div class="product-chapter__copy">
        <span class="product-chapter__eyebrow">Eco-Paints — Emulsion</span>
        <h2 class="product-chapter__name" id="emulsion-chapter-title">
          <?= e($emulsion['name']) ?>
        </h2>
        <p class="product-chapter__desc">
          <?= e($emulsion['descriptor']) ?>. A paint listed for
          interior and exterior walls. Supplied in <?= e($emulsion['packagingShort']) ?> packs.
        </p>
        <dl class="product-chapter__specs">
          <div class="duo-panel__row"><dt>Finish</dt><dd><?= e($emulsion['finish']) ?></dd></div>
          <div class="duo-panel__row"><dt>Drying time</dt><dd><?= e($emulsion['dryingTime']) ?></dd></div>
          <div class="duo-panel__row"><dt>Coverage</dt><dd><?= e($emulsion['coverage']) ?></dd></div>
          <div class="duo-panel__row"><dt>V.O.C.</dt><dd><?= e($emulsion['voc']) ?></dd></div>
        </dl>
        <div class="product-chapter__cta">
          <a class="btn btn--secondary" href="<?= e($emulsion['route']) ?>">View Emulsion</a>
          <a class="btn btn--outline" href="/contact/?interest=prakritik-emulsion">Enquire About Emulsion</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     5. SPEC MATRIX — factual comparison of the two documented formats
     ============================================================ -->
<section class="section section--paper spec-matrix-section" aria-labelledby="compare-title">
  <div class="container">
    <div class="spec-matrix-section__head section-heading section-heading--left" data-reveal>
      <span class="section-heading__eyebrow">Eco-Paints — side by side</span>
      <h2 class="section-heading__title" id="compare-title">Compare the two formats</h2>
    </div>

    <div class="spec-matrix" data-reveal>
      <div class="spec-matrix__row">
        <span class="spec-matrix__col-head">Specification</span>
        <span class="spec-matrix__col-head spec-matrix__col-head--distemper">Prakritik Distemper</span>
        <span class="spec-matrix__col-head spec-matrix__col-head--emulsion">Prakritik Emulsion</span>
      </div>
      <div class="spec-matrix__row">
        <span class="spec-matrix__label">Pack sizes</span>
        <span class="spec-matrix__value"><?= e($distemper['packagingShort']) ?></span>
        <span class="spec-matrix__value"><?= e($emulsion['packagingShort']) ?></span>
      </div>
      <div class="spec-matrix__row">
        <span class="spec-matrix__label">Colour</span>
        <span class="spec-matrix__value"><?= e($distemper['colour']) ?></span>
        <span class="spec-matrix__value"><?= e($emulsion['colour']) ?></span>
      </div>
      <div class="spec-matrix__row">
        <span class="spec-matrix__label">Finish</span>
        <span class="spec-matrix__value"><?= e($distemper['finish']) ?></span>
        <span class="spec-matrix__value"><?= e($emulsion['finish']) ?></span>
      </div>
      <div class="spec-matrix__row">
        <span class="spec-matrix__label">Drying time</span>
        <span class="spec-matrix__value"><?= e($distemper['dryingTime']) ?></span>
        <span class="spec-matrix__value"><?= e($emulsion['dryingTime']) ?></span>
      </div>
      <div class="spec-matrix__row">
        <span class="spec-matrix__label">Coverage</span>
        <span class="spec-matrix__value"><?= e($distemper['coverage']) ?></span>
        <span class="spec-matrix__value"><?= e($emulsion['coverage']) ?></span>
      </div>
      <div class="spec-matrix__row">
        <span class="spec-matrix__label">V.O.C.</span>
        <span class="spec-matrix__value"><?= e($distemper['voc']) ?></span>
        <span class="spec-matrix__value"><?= e($emulsion['voc']) ?></span>
      </div>
      <div class="spec-matrix__row">
        <span class="spec-matrix__label">Usage</span>
        <span class="spec-matrix__value"><?= e($distemper['usage']) ?></span>
        <span class="spec-matrix__value"><?= e($emulsion['usage']) ?></span>
      </div>
    </div>

    <div class="spec-matrix-mobile" data-reveal>
      <div class="spec-matrix-mobile__block">
        <div class="spec-matrix-mobile__name"><?= e($distemper['name']) ?></div>
        <div class="spec-matrix-mobile__row"><span class="k">Pack sizes</span><span class="v"><?= e($distemper['packagingShort']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Colour</span><span class="v"><?= e($distemper['colour']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Finish</span><span class="v"><?= e($distemper['finish']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Drying time</span><span class="v"><?= e($distemper['dryingTime']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Coverage</span><span class="v"><?= e($distemper['coverage']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">V.O.C.</span><span class="v"><?= e($distemper['voc']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Usage</span><span class="v"><?= e($distemper['usage']) ?></span></div>
      </div>
      <div class="spec-matrix-mobile__block spec-matrix-mobile__block--emulsion">
        <div class="spec-matrix-mobile__name"><?= e($emulsion['name']) ?></div>
        <div class="spec-matrix-mobile__row"><span class="k">Pack sizes</span><span class="v"><?= e($emulsion['packagingShort']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Colour</span><span class="v"><?= e($emulsion['colour']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Finish</span><span class="v"><?= e($emulsion['finish']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Drying time</span><span class="v"><?= e($emulsion['dryingTime']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Coverage</span><span class="v"><?= e($emulsion['coverage']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">V.O.C.</span><span class="v"><?= e($emulsion['voc']) ?></span></div>
        <div class="spec-matrix-mobile__row"><span class="k">Usage</span><span class="v"><?= e($emulsion['usage']) ?></span></div>
      </div>
    </div>

    <p class="coverage-disclaimer" style="margin-top: 2rem;">
      <span class="coverage-disclaimer__label">Coverage note</span>
      <span class="coverage-disclaimer__text"><?= e($COVERAGE_DISCLAIMER) ?></span>
    </p>
  </div>
</section>

<!-- ============================================================
     06. COLOUR COLLECTIONS — quiet callout after the format
     comparison (V18 §20). TWO separate collections — never
     "36 unique colours". Swatch strip shows pixel-sampled
     indicative shades from the client card.
     ============================================================ -->
<section class="section section--haldi-wash colour-cta-section" aria-labelledby="colour-cta-title">
  <div class="container">
    <div class="colour-cta" data-reveal>
      <div>
        <span class="colour-cta__eyebrow">Colour Collections</span>
        <h3 class="colour-cta__title" id="colour-cta-title">Two Shade Collections, Inspired by Nature</h3>
        <p class="colour-cta__body">
          <strong>12 Signature shades</strong> and a <strong>Premium
          collection in five groups</strong> — names and codes exactly as
          supplied on the client shade card, previewed live on the wall.
        </p>
      </div>
      <div class="colour-cta__swatch-strip" aria-hidden="true">
        <span class="colour-cta__swatch" style="background: <?= e($SHADE_SIGNATURE[0]['hex']) ?>"></span>
        <span class="colour-cta__swatch" style="background: <?= e($SHADE_SIGNATURE[3]['hex']) ?>"></span>
        <span class="colour-cta__swatch" style="background: <?= e($SHADE_SIGNATURE[4]['hex']) ?>"></span>
        <span class="colour-cta__swatch" style="background: <?= e($SHADE_SIGNATURE[6]['hex']) ?>"></span>
        <span class="colour-cta__swatch" style="background: <?= e($SHADE_SIGNATURE[8]['hex']) ?>"></span>
        <span class="colour-cta__swatch" style="background: <?= e($SHADE_SIGNATURE[10]['hex']) ?>"></span>
        <a class="btn btn--primary" href="/colours/">Explore Colours</a>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     07. COW-DUNG LOGS — development direction (V18 §16–17, V22 rename)
     V22: renamed from "GoCast Logs" to the client's current wording
     (the name printed on the supplied product artwork). The official
     client artwork (2026-10-29 batch) replaces the reference photo.
     NO burn time, density, price, size or wood-equivalent claims.
     Legacy anchor #gocast-logs preserved as an invisible alias.
     ============================================================ -->
<span id="gocast-logs" aria-hidden="true"></span>
<section class="section section--paper family-section" id="cow-dung-logs" aria-labelledby="cowdunglogs-title">
  <div class="container">
    <div class="gocast-feature" data-reveal>
      <figure class="gocast-feature__figure">
        <picture>
          <source type="image/avif" srcset="<?= eco_srcset('carousel-cow-dung-logs', [640, 960, 1280]) ?>"
                  sizes="(min-width: 1024px) 45vw, calc(100vw - 2.5rem)">
          <source type="image/webp" srcset="<?= eco_srcset_webp('carousel-cow-dung-logs', [640, 960, 1280]) ?>"
                  sizes="(min-width: 1024px) 45vw, calc(100vw - 2.5rem)">
          <img src="<?= asset_url('/assets/images/ecosystem/carousel-cow-dung-logs-1280.jpg') ?>"
               alt="Gaurikrit Cow-Dung Logs — official product artwork, premium biomass fuel"
               width="1672" height="941" loading="lazy" decoding="async">
        </picture>
        <figcaption>Cow-Dung Logs — official product artwork.</figcaption>
      </figure>
      <div class="gocast-feature__copy">
        <span class="family-section__num" aria-hidden="true">02</span>
        <h2 class="family-section__name" id="cowdunglogs-title">Cow-Dung Logs</h2>
        <p class="family-section__line">A cow-dung log direction.</p>
        <p>
          A dense log format shaped from cow dung — a development direction
          exploring material uses where wood has traditionally been used.
        </p>
        <ul class="family-section__themes">
          <li>Natural material format</li>
          <li>Traditional-use direction</li>
          <li>Resource-conscious direction</li>
        </ul>
        <p class="muted">
          Cow-Dung Logs is a development direction — the artwork shows the
          client's supplied product visual, not a documented specification.
          Dimensions, composition and availability will be published when the
          client supplies verified information.
        </p>
        <div class="family-section__cta">
          <a class="btn btn--outline" href="/contact/?interest=gocast-logs">Enquire About Cow-Dung Logs</a>
        </div>
      </div>
    </div>
    <div class="family-section__poster" data-reveal>
      <figure class="family-section__poster-figure">
        <picture>
          <source type="image/avif" srcset="<?= eco_srcset('gbp-cow-dung-logs', [640, 960, 1024]) ?>"
                  sizes="(min-width: 1024px) 30vw, calc(100vw - 2.5rem)">
          <source type="image/webp" srcset="<?= eco_srcset_webp('gbp-cow-dung-logs', [640, 960, 1024]) ?>"
                  sizes="(min-width: 1024px) 30vw, calc(100vw - 2.5rem)">
          <img src="<?= asset_url('/assets/images/ecosystem/gbp-cow-dung-logs-1024.jpg') ?>"
               alt="Gaurikrit Cow-Dung Logs product poster — stacked biomass fuel logs. Development direction."
               width="1024" height="1024" loading="lazy" decoding="async">
        </picture>
        <figcaption>Cow-Dung Logs — official product poster.</figcaption>
      </figure>
    </div>
  </div>
</section>

<!-- ============================================================
     08. BIO-BRIQUETTES — development direction (§33, V22 rename)
     V22: renamed from "Bio-Coal Logs" to the client's current wording
     (the name printed on the supplied product artwork). No calorific
     values, emissions percentages, "smokeless" or "carbon neutral" claims.
     Legacy anchor #bio-coal-logs preserved as an invisible alias.
     ============================================================ -->
<span id="bio-coal-logs" aria-hidden="true"></span>
<section class="section section--limewash family-section family-section--reverse" id="bio-briquettes" aria-labelledby="biobriquettes-title">
  <div class="container">
    <div class="family-section__grid" data-reveal>
      <div class="family-section__copy">
        <span class="family-section__num" aria-hidden="true">03</span>
        <h2 class="family-section__name" id="biobriquettes-title">Bio-Briquettes</h2>
        <p class="family-section__line">A bio-based fuel material direction.</p>
        <p class="family-section__status"><span class="status-badge status-badge--futureline" title="Futureline · Not yet in production">Futureline · Not yet in production</span></p>
        <p class="family-section__desc">
          Biomass-based fuel briquettes — a Futureline product direction exploring how
          natural material streams could serve fuel applications. Not yet in production.
        </p>
        <ul class="family-section__themes">
          <li>Bio-based fuel material</li>
          <li>Biomass applications</li>
          <li>Fuel-material direction</li>
          <li>Circular material use</li>
        </ul>
        <p class="family-section__note">
          Bio-Briquettes is a Futureline product — not yet in production. Composition, calorific value
          and test data will be published when the client supplies verified
          information.
        </p>
        <div class="family-section__cta">
          <a class="btn btn--outline" href="/contact/?interest=bio-coal-logs">Enquire About Bio-Briquettes</a>
        </div>
      </div>
      <figure class="family-section__photo" aria-label="Bio-Briquettes — official Gaurikrit product artwork">
        <picture>
          <source type="image/avif" srcset="<?= eco_srcset('carousel-bio-briquettes', [640, 960, 1280, 1920]) ?>"
                  sizes="(min-width: 1024px) 42vw, calc(100vw - 2.5rem)">
          <source type="image/webp" srcset="<?= eco_srcset_webp('carousel-bio-briquettes', [640, 960, 1280, 1920]) ?>"
                  sizes="(min-width: 1024px) 42vw, calc(100vw - 2.5rem)">
          <img src="<?= asset_url('/assets/images/ecosystem/carousel-bio-briquettes-1280.jpg') ?>"
               alt="Gaurikrit Bio-Briquettes — official Gaurikrit artwork for a Futureline product direction not yet in production"
               width="1920" height="1080" loading="lazy" decoding="async">
        </picture>
        <figcaption>Bio-Briquettes official artwork. Futureline — not yet in production.</figcaption>
      </figure>
    </div>
    <div class="family-section__poster" data-reveal>
      <figure class="family-section__poster-figure">
        <picture>
          <source type="image/avif" srcset="<?= eco_srcset('gbp-bio-briquettes', [640, 960, 1024]) ?>"
                  sizes="(min-width: 1024px) 30vw, calc(100vw - 2.5rem)">
          <source type="image/webp" srcset="<?= eco_srcset_webp('gbp-bio-briquettes', [640, 960, 1024]) ?>"
                  sizes="(min-width: 1024px) 30vw, calc(100vw - 2.5rem)">
          <img src="<?= asset_url('/assets/images/ecosystem/gbp-bio-briquettes-1024.jpg') ?>"
               alt="Gaurikrit Bio-Briquettes product poster — cylindrical biomass fuel logs. Futureline product, not yet in production."
               width="1024" height="1024" loading="lazy" decoding="async">
        </picture>
        <figcaption>Bio-Briquettes — official product poster. Futureline, not yet in production.</figcaption>
      </figure>
    </div>
  </div>
</section>

<!-- ============================================================
     9. UTILITY PRODUCTS — development direction (§34)
     No individual products listed; no AI-generated 4-panel image.
     ============================================================ -->
<section class="section section--paper family-section" id="utility-products" aria-labelledby="utility-title">
  <div class="container">
    <div class="family-section__grid" data-reveal>
      <div class="family-section__copy">
        <span class="family-section__num" aria-hidden="true">04</span>
        <h2 class="family-section__name" id="utility-title">Eco Utility Products</h2>
        <p class="family-section__line">A natural-material utility direction.</p>
        <p class="family-section__status"><span class="status-badge status-badge--futureline" title="Futureline · Not yet in production">Futureline · Not yet in production</span></p>
        <p class="family-section__desc">
          Practical daily-use products from naturally derived materials — a
          Futureline product direction for homes, gardens and everyday routines. Not yet in production.
        </p>
        <ul class="family-section__themes">
          <li>Natural-material utility direction</li>
          <li>Moulded material forms</li>
          <li>Home / garden / lifestyle direction</li>
          <li>Circular-economy direction</li>
        </ul>
        <p class="family-section__note">
          Eco Utility Products is a Futureline product — not yet in production. A confirmed product
          list will be published when the client supplies verified information.
        </p>
        <div class="family-section__cta">
          <a class="btn btn--outline" href="/contact/?interest=utility-products">Enquire About Eco Utility Products</a>
        </div>
      </div>
      <figure class="family-section__photo" aria-label="Eco Utility Products — official Gaurikrit product artwork">
        <picture>
          <source type="image/avif" srcset="<?= eco_srcset('carousel-eco-utility-products', [640, 960, 1280, 1920]) ?>"
                  sizes="(min-width: 1024px) 42vw, calc(100vw - 2.5rem)">
          <source type="image/webp" srcset="<?= eco_srcset_webp('carousel-eco-utility-products', [640, 960, 1280, 1920]) ?>"
                  sizes="(min-width: 1024px) 42vw, calc(100vw - 2.5rem)">
          <img src="<?= asset_url('/assets/images/ecosystem/carousel-eco-utility-products-1280.jpg') ?>"
               alt="Gaurikrit Eco Utility Products — official Gaurikrit artwork for a Futureline product direction not yet in production: dhoop cups, cow-dung diyas, biodegradable plates and eco glasses"
               width="1920" height="1080" loading="lazy" decoding="async">
        </picture>
        <figcaption>Eco Utility Products official artwork. Futureline — not yet in production.</figcaption>
      </figure>
    </div>
    <div class="family-section__poster" data-reveal>
      <figure class="family-section__poster-figure">
        <picture>
          <source type="image/avif" srcset="<?= eco_srcset('showcase-utility', [640, 960, 1022]) ?>"
                  sizes="(min-width: 1024px) 30vw, calc(100vw - 2.5rem)">
          <source type="image/webp" srcset="<?= eco_srcset_webp('showcase-utility', [640, 960, 1022]) ?>"
                  sizes="(min-width: 1024px) 30vw, calc(100vw - 2.5rem)">
          <img src="<?= asset_url('/assets/images/ecosystem/showcase-utility-1022.jpg') ?>"
               alt="Gaurikrit Eco Utility Products showcase — dhoop cups and cow-dung diyas. Futureline product, not yet in production."
               width="1022" height="1095" loading="lazy" decoding="async">
        </picture>
        <figcaption>Eco Utility Products showcase — dhoop cups and cow-dung diyas. Futureline, not yet in production.</figcaption>
      </figure>
    </div>
  </div>
</section>

<!-- ============================================================
     10. APPLICATION MAP — where the ecosystem works (§35)
     ============================================================ -->
<section class="section section--haldi-wash appmap-section" aria-labelledby="appmap-title">
  <div class="container">
    <div class="appmap-section__head section-heading section-heading--left" data-reveal>
      <span class="section-heading__eyebrow">Application map</span>
      <h2 class="section-heading__title" id="appmap-title">Where the Ecosystem Works</h2>
    </div>
    <div class="app-matrix" data-reveal-stagger>
      <?php foreach ($APPLICATION_GROUPS as $group): ?>
        <div class="app-group">
          <h3 class="app-group__title"><?= e($group['title']) ?></h3>
          <ul class="app-group__list">
            <?php foreach ($group['items'] as $item): ?>
              <li class="app-group__item<?= $item['live'] ? ' app-group__item--live' : ' app-group__item--direction' ?>">
                <?php if ($item['href']): ?>
                  <a href="<?= e($item['href']) ?>"><?= e($item['name']) ?></a>
                <?php else: ?>
                  <span><?= e($item['name']) ?></span>
                <?php endif; ?>
                <span class="app-group__item-tag"><?= $item['live'] ? 'Family' : 'Direction' ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endforeach; ?>
    </div>
    <p class="app-matrix-note" data-reveal>
      Entries marked <strong>Direction</strong> are application areas under exploration —
      not products currently for sale.
    </p>
  </div>
</section>

<!-- ============================================================
     11. NEED HELP CHOOSING — CTA (V18 §41: FAQ retired to the detail
     pages' context; products stays the ecosystem catalogue)
     ============================================================ -->
<section class="section section--forest" aria-labelledby="choose-cta-title">
  <div class="container">
    <div class="why-cta" data-reveal>
      <span class="why-cta__eyebrow">Still deciding?</span>
      <h2 class="why-cta__title" id="choose-cta-title">Need help choosing? Talk to Gaurikrit</h2>
      <p class="why-cta__sub">
        We can walk through your project — interior or exterior, fresh walls or
        repainting — and help you pick the right Prakritik format.
      </p>
      <div class="why-cta__actions">
        <a class="btn btn--haldi" href="/contact/">Talk to Us</a>
        <a class="btn btn--secondary" href="/paint-calculator/">Painting Calculator</a>
      </div>
    </div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php';
